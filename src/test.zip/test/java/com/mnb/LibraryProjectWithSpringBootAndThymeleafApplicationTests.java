package com.mnb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryProjectWithSpringBootAndThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}


}
